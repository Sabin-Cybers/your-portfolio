import Link from 'next/link'
import { Linkedin, Instagram, Github } from 'lucide-react'

const Footer = () => {
  const currentYear = new Date().getFullYear()
  const socialLinks = [
    { name: 'LinkedIn', icon: Linkedin, href: 'https://www.linkedin.com/in/yourusername' },
    { name: 'Instagram', icon: Instagram, href: 'https://www.instagram.com/yourusername' },
    { name: 'GitHub', icon: Github, href: 'https://github.com/yourusername' },
  ]

  return (
    <footer className="bg-slate-800 text-white py-8">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="mb-4 md:mb-0">&copy; {currentYear} Your Name. All rights reserved.</p>
          <div className="flex space-x-4">
            {socialLinks.map((link) => (
              <Link 
                key={link.name} 
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-sky-400 transition-colors"
              >
                <link.icon className="w-6 h-6" />
                <span className="sr-only">{link.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

